
const txt='Today the legend turns 18! 😎';
let i=0;function type(){if(i<txt.length){t.innerHTML+=txt[i++];setTimeout(type,50)}}type();
function load(){
['photo1.jpg','photo2.jpg','photo3.jpg','photo4.jpg'].forEach(f=>{
let im=document.getElementById(f);
im.src='photos/'+f;
im.onerror=()=>{im.alt='Add '+f;}
});
}
function surprise(){
document.getElementById('sec').classList.remove('hide');
fire();
}
function fire(){
const c=document.getElementById('c'),x=c.getContext('2d');c.width=innerWidth;c.height=innerHeight;
let p=[];for(let i=0;i<200;i++)p.push({x:innerWidth/2,y:innerHeight/2,vx:(Math.random()-.5)*8,vy:(Math.random()-.5)*8,l:80});
(function a(){x.clearRect(0,0,c.width,c.height);p.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.l--;x.fillStyle='hsl('+Math.random()*360+',100%,60%)';x.fillRect(q.x,q.y,3,3)});p=p.filter(q=>q.l>0);if(p.length)requestAnimationFrame(a);})();
}
window.onload=load;
