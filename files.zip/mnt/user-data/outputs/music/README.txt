Add your birthday song here with this exact filename:

song.mp3

The website automatically loads and plays it through the music player at the bottom of the page.
